/*
Name: YOUR NAME
Registration No: YOUR REGISTRATION NUMBER
*/

// Get HTML elements
const taskForm = document.getElementById("taskForm");
const taskInput = document.getElementById("taskInput");
const taskList = document.getElementById("taskList");
const errorMessage = document.getElementById("errorMessage");

const totalTasks = document.getElementById("totalTasks");
const remainingTasks = document.getElementById("remainingTasks");

const clearCompleted = document.getElementById("clearCompleted");
const filters = document.querySelector(".filters");

let currentFilter = "all";

// Add Task
taskForm.addEventListener("submit", function (event) {

    event.preventDefault();

    const taskText = taskInput.value.trim();

    // Check empty task
    if (taskText === "") {
        showError("Please enter a task.");
        return;
    }

    // Check duplicate task
    const tasks = document.querySelectorAll(".task-text");

    for (let task of tasks) {
        if (task.textContent.toLowerCase() === taskText.toLowerCase()) {
            showError("This task already exists.");
            return;
        }
    }

    // Create task
    createTask(taskText);

    taskInput.value = "";
    errorMessage.textContent = "";

    updateCounter();
    applyFilter();
});


// Create Task Function
function createTask(text) {

    const li = document.createElement("li");

    li.className = "task";

    li.innerHTML = `
        <input type="checkbox" class="complete-checkbox">

        <span class="task-text">${text}</span>

        <button class="delete-btn">Delete</button>
    `;

    taskList.appendChild(li);
}


// Event Delegation
taskList.addEventListener("click", function (event) {

    const task = event.target.closest(".task");

    if (!task) {
        return;
    }

    // Delete task
    if (event.target.classList.contains("delete-btn")) {

        task.remove();

        updateCounter();
        applyFilter();

        return;
    }

    // Complete task
    if (event.target.classList.contains("complete-checkbox")) {

        task.classList.toggle(
            "completed",
            event.target.checked
        );

        updateCounter();
        applyFilter();
    }

});


// Double-click to edit
taskList.addEventListener("dblclick", function (event) {

    if (!event.target.classList.contains("task-text")) {
        return;
    }

    const span = event.target;
    const oldText = span.textContent;

    const input = document.createElement("input");

    input.type = "text";
    input.value = oldText;
    input.className = "edit-input";

    span.replaceWith(input);

    input.focus();

    // Enter = save
    input.addEventListener("keydown", function (event) {

        if (event.key === "Enter") {

            const newText = input.value.trim();

            if (newText !== "") {
                span.textContent = newText;
                input.replaceWith(span);
            } else {
                input.replaceWith(span);
            }

        }

        // Escape = cancel
        if (event.key === "Escape") {
            input.replaceWith(span);
        }

    });

});


// Filter buttons
filters.addEventListener("click", function (event) {

    if (!event.target.classList.contains("filter")) {
        return;
    }

    currentFilter = event.target.dataset.filter;

    document.querySelectorAll(".filter").forEach(function (button) {
        button.classList.remove("active");
    });

    event.target.classList.add("active");

    applyFilter();
});


// Apply Filter
function applyFilter() {

    const tasks = document.querySelectorAll(".task");

    tasks.forEach(function (task) {

        const completed = task.classList.contains("completed");

        if (currentFilter === "all") {
            task.style.display = "flex";
        }

        else if (currentFilter === "active") {

            if (completed) {
                task.style.display = "none";
            } else {
                task.style.display = "flex";
            }

        }

        else if (currentFilter === "completed") {

            if (completed) {
                task.style.display = "flex";
            } else {
                task.style.display = "none";
            }

        }

    });
}


// Clear completed tasks
clearCompleted.addEventListener("click", function () {

    document.querySelectorAll(".task.completed").forEach(function (task) {
        task.remove();
    });

    updateCounter();
    applyFilter();
});


// Update Counter
function updateCounter() {

    const tasks = document.querySelectorAll(".task");

    const completed = document.querySelectorAll(
        ".task.completed"
    );

    totalTasks.textContent = tasks.length;

    remainingTasks.textContent =
        tasks.length - completed.length;
}


// Show Error
function showError(message) {

    errorMessage.textContent = message;

    setTimeout(function () {
        errorMessage.textContent = "";
    }, 3000);
}